# ⚔️ LIFE RPG OS
Transforme sua vida em um RPG.

Versão V3 — sistema de progressão reconstruído para evitar inflação de XP quando uma atividade desenvolve várias capacidades.

## Como funciona
- A missão escolhe **um único galho principal**: Atributo → Habilidade → Semi-habilidade.
- A missão pode gerar **efeitos automáticos secundários**, definidos pelo tipo da atividade. O jogador não escolhe vários galhos para multiplicar XP.
- O XP do galho é distribuído em cascata com pesos controlados; o XP do personagem é independente.
- Valores derivados (XP, níveis, rank e vidas) não têm edição manual.
- localStorage, backup JSON, rotina, livros, treino, Pomodoro, chefões, eventos, conquistas, títulos, loja e histórico.

## Netlify
Envie a pasta inteira. `_redirects` já está configurado para SPA.
